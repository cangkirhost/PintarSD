package net.cangkirhost.pintarsd;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Semua pengaturan & status kunci disimpan di SharedPreferences. */
public final class Store {
    private Store() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences("pintar", Context.MODE_PRIVATE);
    }

    // ---- pengaturan orang tua ----
    public static int grade(Context c) { return p(c).getInt("grade", 1); }
    public static int sets(Context c) { return p(c).getInt("sets", 1); }
    public static int minCorrect(Context c) { return p(c).getInt("minCorrect", 7); }
    public static int minutes(Context c) { return p(c).getInt("minutes", 60); }
    public static String pin(Context c) { return p(c).getString("pin", ""); }

    public static void saveSettings(Context c, int grade, int sets, int minCorrect, int minutes) {
        p(c).edit().putInt("grade", grade).putInt("sets", sets)
                .putInt("minCorrect", minCorrect).putInt("minutes", minutes).apply();
    }

    public static void setPin(Context c, String pin) { p(c).edit().putString("pin", pin).apply(); }

    // ---- status misi ----
    public static int progress(Context c) { return p(c).getInt("progress", 0); }

    public static void incProgress(Context c) {
        p(c).edit().putInt("progress", progress(c) + 1).apply();
    }

    // ---- status kunci ----
    public static long until(Context c) { return p(c).getLong("unlockUntil", 0L); }

    public static boolean isLocked(Context c) {
        return System.currentTimeMillis() >= until(c);
    }

    public static void unlockFor(Context c, int minutes) {
        long until = System.currentTimeMillis() + minutes * 60_000L;
        p(c).edit().putLong("unlockUntil", until).putInt("progress", 0).apply();
        scheduleAlarm(c, until);
    }

    public static void lockNow(Context c) {
        p(c).edit().putLong("unlockUntil", 0L).apply();
        cancelAlarm(c);
    }

    private static PendingIntent alarmIntent(Context c) {
        Intent i = new Intent(c, ExpireReceiver.class);
        return PendingIntent.getBroadcast(c, 1, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    public static boolean canExactAlarm(Context c) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        return am != null && am.canScheduleExactAlarms();
    }

    public static void scheduleAlarm(Context c, long at) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = alarmIntent(c);
        try {
            if (canExactAlarm(c)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } else {
                am.setWindow(AlarmManager.RTC_WAKEUP, at, 60_000L, pi);
            }
        } catch (SecurityException e) {
            am.setWindow(AlarmManager.RTC_WAKEUP, at, 60_000L, pi);
        }
    }

    public static void cancelAlarm(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(alarmIntent(c));
    }

    // ---- riwayat ----
    public static void addHistory(Context c, String title, int right, int total) {
        try {
            JSONArray arr = new JSONArray(p(c).getString("history", "[]"));
            JSONObject o = new JSONObject();
            o.put("t", System.currentTimeMillis());
            o.put("title", title);
            o.put("r", right);
            o.put("n", total);
            arr.put(o);
            while (arr.length() > 50) arr.remove(0);
            p(c).edit().putString("history", arr.toString()).apply();
        } catch (JSONException ignored) {
        }
    }

    public static JSONArray history(Context c) {
        try {
            return new JSONArray(p(c).getString("history", "[]"));
        } catch (JSONException e) {
            return new JSONArray();
        }
    }
}
