package net.cangkirhost.pintarsd;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Setelah tablet dinyalakan ulang, pasang lagi alarm waktu bebas bila masih berjalan. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        if (!Store.isLocked(ctx)) Store.scheduleAlarm(ctx, Store.until(ctx));
    }
}
